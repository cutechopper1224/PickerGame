import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.TimerTask;

import javax.imageio.ImageIO;
import javax.swing.*;
public class Level1 extends JFrame implements ActionListener,KeyListener{

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	private JLabel[] picLife = new JLabel[5];
	int charX,charY;
	private BufferedImage picChar,picLose;
	private Image offScreenImage;
	private BufferedImage[] Items = new BufferedImage[15];
	final int LEFT_BORDER = 50,RIGHT_BORDER = 1000,UP_BORDER = 100,DOWN_BORDER = 600;
	final int WINDOW_BOTTOM = 700;
	final int LEVEL_MAX_ITEM = 10;
	final int MAX_PROP_IN_PLACE = 15;
	final int MAX_ITEM_KIND = 11;
	final int X_OFFSET = 50,Y_OFFSET = 50;
	private Prop[] Props = new Prop[MAX_PROP_IN_PLACE];
	private String[] itemName = {"good1","good2","good3","good4","bad1","bad2","bad3","bad4","minus","plus","block"};
	JLabel score;
	boolean lose = false;
	
	int currentScore = 0;
	int currentLife = 3;
	java.util.Timer timer1 = new java.util.Timer();
	java.util.Timer timer2 = new java.util.Timer();
	java.util.Timer timer3 = new java.util.Timer();
	private int dropSpeed = 20;
	private int chaseSpeed = 80;
	TimerTask Drop = new TimerTask() {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			for(int i = 0;i < MAX_PROP_IN_PLACE;i++) {
				if(Props[i].type == Prop.ItemType.GOOD || Props[i].type == Prop.ItemType.BAD || Props[i].type == Prop.ItemType.PLUS ||  Props[i].type == Prop.ItemType.BLOCK) {
					Props[i].y += dropSpeed;
					if(Props[i].y > WINDOW_BOTTOM) {
						Props[i].type = Prop.ItemType.NONE;
					}
				}
				else if(Props[i].type == Prop.ItemType.MINUS) {
					Props[i].y += chaseSpeed;
					if(Props[i].x < charX) {
						Props[i].x += chaseSpeed;
					}
					else if(Props[i].x > charX){
						Props[i].x -= chaseSpeed;
					}
					if(Props[i].y > WINDOW_BOTTOM) {
						Props[i].type = Prop.ItemType.NONE;
					}
				}
			}
			
		}
		
	};
	
	TimerTask Check = new TimerTask() {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			for(int i = 0;i < MAX_PROP_IN_PLACE;i++ ) {
				
				if(Math.abs(charX - Props[i].x) <= X_OFFSET && Math.abs(charY - Props[i].y) <= Y_OFFSET )
				{
				if(Props[i].type == Prop.ItemType.GOOD) {
					ChangeScore(100);
					Props[i].type = Prop.ItemType.NONE;
				}
				else if(Props[i].type == Prop.ItemType.BAD) {
					Props[i].type = Prop.ItemType.NONE;
					ChangeScore(-100);
				}
				
				else if(Props[i].type == Prop.ItemType.MINUS) {
					Props[i].type = Prop.ItemType.NONE;
					ChangeScore(0);
					changeLife(false);
				}
				
				else if(Props[i].type == Prop.ItemType.PLUS) {
					Props[i].type = Prop.ItemType.NONE;
					ChangeScore(0);//To trigger changes in graphic
					changeLife(true);
				}
				
				if(Props[i].y <= charY && Props[i].type == Prop.ItemType.BLOCK) {
					charY += 20;
					if(charY >= WINDOW_BOTTOM) {
						changeLife(false);
						charY -= 100;
					}
				}
				
				
				}
				
				
			}
			repaint();
		}
	
		
	};
	
	TimerTask Spawn = new TimerTask() {

		@Override
		public void run() {
			// TODO Auto-generated method stub
			for(int i = 0;i < MAX_PROP_IN_PLACE;i++) {
				if(Props[i].type == Prop.ItemType.NONE) {
					GenerateItem(i);
					break;
				}
			}
			
			for(int i = 0;i < MAX_PROP_IN_PLACE;i++) {
				if(Props[i].type == Prop.ItemType.NONE) {
					GenerateItem(i);
					break;
				}
			}
		}

		
		
	};
	
	private void GenerateItem(int i) {
		// TODO Auto-generated method stub
		Random r = new Random();
		int kind = r.nextInt(100);
		if(kind <= 39) {
			Props[i].type = Prop.ItemType.GOOD;
			Props[i].index = r.nextInt(4);
		}
		else if(kind <= 69) {
			Props[i].type = Prop.ItemType.BAD;
			Props[i].index = r.nextInt(4) + 4;
		}
		
		else if(kind <= 89) {
			Props[i].type = Prop.ItemType.BLOCK;
			Props[i].index = 10;
		}
		
		else if(kind <= 97) {
			Props[i].type = Prop.ItemType.MINUS;
			Props[i].index = 8;
		}
		
		else {
			Props[i].type = Prop.ItemType.PLUS;
			Props[i].index = 9;
		}
		
		
		
		Props[i].x = r.nextInt(RIGHT_BORDER);
		Props[i].y = 0;
		
	}
	
	public Level1() {
		setSize(1600,800);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLayout(null);
		ImageIcon icon = new ImageIcon("pic//coast.jpg");
		JLabel back = new JLabel(icon);
		back.setLocation(0, 0);
		back.setSize(1200,800);
		this.getLayeredPane().add(back,-1);
		currentScore = 0;
		lose = false;
		ImageIcon icon2 = new ImageIcon("pic//board.jpg");
		JLabel board = new JLabel(icon2);
		board.setLocation(1200,35);
		board.setSize(400,800);
		
		
		
		charX = 575;
		charY = 625;
		
		JLabel title = new JLabel(new ImageIcon(""));
		
		title.setLocation(1000,50);
		title.setSize(800,100);
		title.setText("Level1");
	  title.setFont(new Font("monospaced", Font.BOLD, 30));
		this.getLayeredPane().add(title,1);
		
       score = new JLabel(new ImageIcon(""));
		
       score.setLocation(1000,250);
       score.setSize(800,100);
       score.setText("Score:0");
       score.setFont(new Font("monospaced", Font.BOLD, 30));
       score.setForeground(Color.BLUE);
		this.getLayeredPane().add(score,1);
		
		for(int i = 0;i < 5;i++) {
			picLife[i] = new JLabel(new ImageIcon("pic//crystal.png"));
			picLife[i].setSize(60,60);
			picLife[i].setLocation(1225 + 70 * i,500);
				this.getLayeredPane().add(picLife[i],1);
				if(i > 2) {
					picLife[i].setVisible(false);
				}
		}
		
		for(int i = 0;i < MAX_PROP_IN_PLACE;i++) {
			Props[i] = new Prop();
		}
		Props[0].index = 9;
		Props[0].x = 250;
		Props[0].y = 250;
		Props[0].type = Prop.ItemType.PLUS;
		
		Props[1].index = 10;
		Props[1].x = 400;
		Props[1].y = 400;
		Props[1].type = Prop.ItemType.BLOCK;
		LoadImage();
		
		addKeyListener(this);
		timer1.schedule(Drop, 100, 1000);
		timer2.schedule(Check, 100, 100);
		timer3.schedule(Spawn, 100,4000);
		currentLife = 3;
		
	}
	
	public void ChangeScore(int amount) {
		currentScore += amount;
		score.setText("Score: " + String.valueOf(currentScore));
	}
	
	public void LoadImage() {
		try {
			picChar = ImageIO.read(new File("pic//char.png"));
			for(int i = 0;i < MAX_ITEM_KIND;i++) {
				Items[i] = ImageIO.read(new File("pic//" + itemName[i] + ".png"));
			}
			picLose = ImageIO.read(new File("pic//lose.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public void changeLife(boolean kind) {
		if(kind) {
			currentLife++;
			if(currentLife > 5)
				currentLife = 5;
			picLife[currentLife - 1].setVisible(true);
		}
		else {
			picLife[currentLife - 1].setVisible(false);
			currentLife--;
			if(currentLife == 0)
				loseGame();
			
		}
	}
	
	
	
	public void paint(Graphics g) {
		
			offScreenImage = this.createImage(1600,800);//For Buffer
			Graphics gImage = offScreenImage.getGraphics();
		    gImage.setColor(gImage.getColor());
		    gImage.fillRect(0, 0, 1600, 800);
		
		if(!lose) {
			super.paint(gImage);
			for(int i = 0;i < MAX_PROP_IN_PLACE;i++ ) {
				if(Props[i].type != Prop.ItemType.NONE) {
					gImage.drawImage(Items[Props[i].index], Props[i].x, Props[i].y, null);
				}
			}
			gImage.drawImage(picChar, charX, charY, null);
			Random r = new Random();
			int index = r.nextInt(LEVEL_MAX_ITEM);

			g.drawImage(offScreenImage, 0,0, null);
		}
		else {
			g.drawImage(picLose, 0, 0, null);
		}

		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Level1 frame = new Level1();
        frame.setVisible(true);
        frame.setTitle("Picker");
        
	}
	
	public void loseGame() {
		lose = true;
		timer1.cancel();
		timer2.cancel();
		timer3.cancel();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		char input = Character.toLowerCase(e.getKeyChar());
		if(input == 'a' && charX >= LEFT_BORDER) {
			charX -= 50;
			
		}
		
		if(input == 'd' && charX <= RIGHT_BORDER) {
			charX += 50;
			
		}
		
		if(input == 'w' && charY >= UP_BORDER) {
			charY -= 50;
		
		}
		
		if(input == 's' && charY <= DOWN_BORDER) {
			charY += 50;
			
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
