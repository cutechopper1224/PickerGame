
public class Prop {
	public int x,y,index;
	
	public enum ItemType{
		NONE,
		GOOD,
		BAD,
		MINUS,
		PLUS,
		BLOCK
	}
	public ItemType type;
	public Prop() {
		x = 0;
		y = 0;
		index = 0;
		type = ItemType.NONE;
	}
}
